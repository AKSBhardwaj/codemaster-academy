# DSA in six languages

Each lesson teaches the same idea in JavaScript, C, C++, Python, C#, and Java.
Extract (unzip) the download first. Pick one language. Open its folder, then open a lesson folder.
The program in that folder is complete. Compare its result with expected-output.txt.
Try changing one small value, then run it again.

## Tools and commands

Install the tool for your language first. Open a terminal in the lesson folder.

| Language | Tool | Command |
| --- | --- | --- |
| JavaScript | Node.js (a current supported version) | node main.js |
| Python | Python 3 | python main.py (or python3 main.py) |
| C | GCC or Clang with C11 | gcc -std=c11 main.c -o main |
| C++ | GCC or Clang with C++17 | g++ -std=c++17 main.cpp -o main |
| Java | JDK 17 or newer | First: javac Main.java. Next: java Main. |
| C# | .NET SDK 8 or newer | dotnet run --project DsaPractice.csproj |

After compiling C or C++, run ./main on macOS/Linux or .\main.exe in Windows PowerShell.
For Java, enter javac Main.java and press Enter. Then enter java Main and press Enter.
You can replace gcc with clang, or g++ with clang++, if you installed Clang.
Python on Windows may use py instead of python.
The C# projects target .NET 8 and allow a newer installed runtime. The first build may
download .NET reference files. Install the SDK, not just the runtime.

## Read before you begin

The website can run the JavaScript examples. The other five languages run on your computer.
No accounts, web server, database, or paid service are needed for these DSA examples.
These are small teaching programs. Read each lesson's limits before using the ideas in a larger app.
C arrays have fixed limits in several examples; stay within the sizes explained in the lesson.
Run one program at a time. In Java, each folder has its own class named Main.

The source files and expected results are generated from the website lessons during the build.
