#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *left; struct Node *right; };
int sum(const struct Node *node) {
    if (node == NULL) return 0;
    return node->value + sum(node->left) + sum(node->right);
}

int main(void) {
    struct Node left = {3, NULL, NULL};
    struct Node right = {10, NULL, NULL};
    struct Node root = {8, &left, &right};
    printf("%d\n", sum(&root));
    return 0;
}
