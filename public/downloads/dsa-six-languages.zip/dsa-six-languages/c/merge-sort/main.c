#include <stdio.h>
#include <stdlib.h>

void mergeSort(int a[], int buffer[], int left, int right) {
    if (left >= right) return;
    int mid = left + (right - left) / 2;
    mergeSort(a, buffer, left, mid);
    mergeSort(a, buffer, mid + 1, right);
    int i = left, j = mid + 1, k = left;
    while (i <= mid && j <= right) {
        if (a[i] <= a[j]) buffer[k++] = a[i++];
        else buffer[k++] = a[j++];
    }
    while (i <= mid) buffer[k++] = a[i++];
    while (j <= right) buffer[k++] = a[j++];
    for (int pos = left; pos <= right; pos++) a[pos] = buffer[pos];
}

int main(void) {
    int a[] = {4, 2, 3, 1};
    int n = sizeof a / sizeof a[0];
    int *buffer = malloc((size_t)n * sizeof *buffer);
    if (n > 0 && buffer == NULL) return 1;
    mergeSort(a, buffer, 0, n - 1);
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", a[i]);
    }
    printf("\n");
    free(buffer);
    return 0;
}
