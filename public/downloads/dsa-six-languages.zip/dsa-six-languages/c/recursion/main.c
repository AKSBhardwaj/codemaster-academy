#include <stdio.h>
#include <stdlib.h>

int sumTo(int n) {
    if (n == 0) return 0;
    return n + sumTo(n - 1);
}

int main(void) {
    printf("%d\n", sumTo(4));
    printf("%d\n", sumTo(0));
    return 0;
}
