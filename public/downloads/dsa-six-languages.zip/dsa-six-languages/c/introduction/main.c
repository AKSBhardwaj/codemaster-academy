#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int scores[] = {4, 7, 2};
    int total = 0;
    for (int i = 0; i < 3; i++) {
        total += scores[i];
    }
    printf("%d\n", total);
    return 0;
}
