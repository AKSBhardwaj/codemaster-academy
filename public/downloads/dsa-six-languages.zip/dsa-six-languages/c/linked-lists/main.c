#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };

int main(void) {
    struct Node last = {9, NULL};
    struct Node middle = {6, &last};
    struct Node first = {3, &middle};
    struct Node *head = &first;
    struct Node *current = head;
    while (current != NULL) {
        printf("%d\n", current->value);
        current = current->next;
    }
    return 0;
}
