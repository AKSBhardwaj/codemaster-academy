#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int input[] = {4, 4, 7};
    int unique[3];
    int size = 0;
    for (int i = 0; i < 3; i++) {
        int found = 0;
        for (int j = 0; j < size; j++) {
            if (unique[j] == input[i]) found = 1;
        }
        if (!found && size < 3) unique[size++] = input[i];
    }
    int hasSeven = 0;
    for (int j = 0; j < size; j++) {
        if (unique[j] == 7) hasSeven = 1;
    }
    printf("%d\n%d\n", size, hasSeven);
    return 0;
}
