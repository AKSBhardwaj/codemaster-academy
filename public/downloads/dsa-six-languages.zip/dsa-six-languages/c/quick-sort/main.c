#include <stdio.h>
#include <stdlib.h>

int partition(int a[], int low, int high) {
    int pivot = a[high];
    int place = low;
    for (int i = low; i < high; i++) {
        if (a[i] <= pivot) {
            int temp = a[i];
            a[i] = a[place];
            a[place] = temp;
            place++;
        }
    }
    int pivotTemp = a[place];
    a[place] = a[high];
    a[high] = pivotTemp;
    return place;
}

void quickSort(int a[], int low, int high) {
    if (low >= high) return;
    int pivotPosition = partition(a, low, high);
    quickSort(a, low, pivotPosition - 1);
    quickSort(a, pivotPosition + 1, high);
}

int main(void) {
    int a[] = {4, 2, 3, 1};
    int n = sizeof a / sizeof a[0];
    quickSort(a, 0, n - 1);
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", a[i]);
    }
    printf("\n");
    return 0;
}
