#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *left; struct Node *right; };

int main(void) {
    struct Node left = {3, NULL, NULL};
    struct Node right = {10, NULL, NULL};
    struct Node root = {8, &left, &right};
    struct Node * current = &root;
    int target = 10;
    int found = -1;
    while (current != NULL) {
        if (target == current->value) {
            found = current->value;
            break;
        }
        current = target < current->value ? current->left : current->right;
    }
    printf("%d\n", found);
    return 0;
}
