#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int a[] = {1, 2, 4, 6, 8};
    int target = 10;
    int n = sizeof a / sizeof a[0];
    int left = 0, right = n - 1;
    int found = 0;
    while (left < right) {
        int sum = a[left] + a[right];
        if (sum == target) {
            found = 1;
            break;
        }
        if (sum < target) left++;
        else right--;
    }
    if (found) printf("%d %d\n", left, right);
    else printf("not found\n");
    return 0;
}
