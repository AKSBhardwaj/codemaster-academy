#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int graph[4][2] = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    int seen[4] = {0};
    int queue[4];
    int head = 0, tail = 0;
    queue[tail++] = 0;
    seen[0] = 1;
    while (head < tail) {
        int current = queue[head++];
        for (int i = 0; i < 2; i++) {
            int next = graph[current][i];
            if (!seen[next]) {
                seen[next] = 1;
                queue[tail++] = next;
            }
        }
    }
    for (int i = 0; i < tail; i++) {
        if (i > 0) printf(" ");
        printf("%d", queue[i]);
    }
    printf("\n");
    return 0;
}
