#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int scores[] = {3, 6, 9};
    int target = 9;
    int checks = 0;
    for (int i = 0; i < 3; i++) {
        checks++;
        if (scores[i] == target) break;
    }
    printf("%d\n", checks);
    return 0;
}
