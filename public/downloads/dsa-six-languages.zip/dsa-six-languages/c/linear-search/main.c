#include <stdio.h>
#include <stdlib.h>

int findFirst(const int a[], int n, int target) {
    for (int i = 0; i < n; i++) {
        if (a[i] == target) return i;
    }
    return -1;
}

int main(void) {
    int a[] = {9, 4, 7, 4};
    int n = sizeof a / sizeof a[0];
    printf("%d\n", findFirst(a, n, 7));
    printf("%d\n", findFirst(a, n, 6));
    return 0;
}
