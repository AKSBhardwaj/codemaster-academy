#include <stdio.h>
#include <stdlib.h>

struct Node {
    int value;
    struct Node *left;
    struct Node *right;
};

void inorder(const struct Node *node, int order[], int *count) {
    if (node == NULL) return;
    inorder(node->left, order, count);
    order[*count] = node->value;
    (*count)++;
    inorder(node->right, order, count);
}

int main(void) {
    struct Node one = {1, NULL, NULL};
    struct Node three = {3, NULL, NULL};
    struct Node two = {2, &one, &three};
    struct Node six = {6, NULL, NULL};
    struct Node root = {4, &two, &six};
    int order[5];
    int count = 0;
    inorder(&root, order, &count);
    for (int i = 0; i < count; i++) {
        if (i > 0) printf(" ");
        printf("%d", order[i]);
    }
    printf("\n");
    return 0;
}
