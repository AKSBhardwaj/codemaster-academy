#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int scores[] = {4, 7, 2};
    int length = (int)(sizeof scores / sizeof scores[0]);
    int index = 1;
    if (index >= 0 && index < length) {
        scores[index] = 9;
        printf("%d\n", scores[index]);
    }
    return 0;
}
