#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int a[] = {4, 2, 3, 1};
    int n = sizeof a / sizeof a[0];
    for (int start = 0; start < n - 1; start++) {
        int smallest = start;
        for (int i = start + 1; i < n; i++) {
            if (a[i] < a[smallest]) smallest = i;
        }
        int temp = a[start];
        a[start] = a[smallest];
        a[smallest] = temp;
    }
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", a[i]);
    }
    printf("\n");
    return 0;
}
