#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int edges[3][3] = {{0, 1, 1}, {1, 0, 0}, {1, 0, 0}};
    int vertex = 0;
    if (vertex >= 0 && vertex < 3) {
        for (int neighbour = 0; neighbour < 3; neighbour++) {
            if (edges[vertex][neighbour] == 1) printf("%d\n", neighbour);
        }
    }
    return 0;
}
