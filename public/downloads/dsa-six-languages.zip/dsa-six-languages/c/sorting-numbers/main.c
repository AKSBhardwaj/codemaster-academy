#include <stdio.h>
#include <stdlib.h>

int compareNumbers(const void *left, const void *right) {
    int x = *(const int *)left;
    int y = *(const int *)right;
    return (x > y) - (x < y);
}

int main(void) {
    int a[] = {10, 2, 30};
    int n = sizeof a / sizeof a[0];
    qsort(a, n, sizeof a[0], compareNumbers);
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", a[i]);
    }
    printf("\n");
    return 0;
}
