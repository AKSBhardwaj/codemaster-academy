#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int stack[3];
    int size = 0;
    if (size < 3) stack[size++] = 10;
    if (size < 3) stack[size++] = 20;
    if (size > 0) printf("%d\n", stack[--size]);
    if (size > 0) printf("%d\n", stack[size - 1]);
    return 0;
}
