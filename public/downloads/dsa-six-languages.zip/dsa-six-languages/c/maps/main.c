#include <stdio.h>
#include <stdlib.h>
struct Pair { int key; int value; };

int main(void) {
    struct Pair books[] = {{2, 3}, {5, 1}};
    int size = 2;
    for (int i = 0; i < size; i++) {
        if (books[i].key == 2) books[i].value = 6;
    }
    for (int i = 0; i < size; i++) {
        if (books[i].key == 2) {
            printf("%d\n", books[i].value);
            break;
        }
    }
    printf("%d\n", size);
    return 0;
}
