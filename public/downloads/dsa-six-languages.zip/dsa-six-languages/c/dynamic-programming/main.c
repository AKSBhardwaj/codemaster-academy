#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int n = 4;
    int *ways = calloc((size_t)n + 1, sizeof *ways);
    if (ways == NULL) return 1;
    ways[0] = 1;
    for (int step = 1; step <= n; step++) {
        ways[step] = ways[step - 1];
        if (step >= 2) ways[step] += ways[step - 2];
    }
    printf("%d\n", ways[n]);
    free(ways);
    return 0;
}
