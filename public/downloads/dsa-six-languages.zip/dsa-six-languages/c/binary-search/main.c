#include <stdio.h>
#include <stdlib.h>

int binarySearch(const int a[], int n, int target) {
    int low = 0;
    int high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

int main(void) {
    int a[] = {2, 4, 6, 8, 10};
    int n = sizeof a / sizeof a[0];
    printf("%d\n", binarySearch(a, n, 8));
    printf("%d\n", binarySearch(a, n, 7));
    return 0;
}
