#include <stdio.h>
#include <stdlib.h>

int main(void) {
    printf("%d\n", 4 + 7 + 2);
    return 0;
}
