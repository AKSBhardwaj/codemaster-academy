#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int queue[3];
    int head = 0;
    int tail = 0;
    if (tail < 3) queue[tail++] = 10;
    if (tail < 3) queue[tail++] = 20;
    if (head < tail) printf("%d\n", queue[head++]);
    if (head < tail) printf("%d\n", queue[head]);
    return 0;
}
