#include <stdio.h>
#include <stdlib.h>

void visit(int graph[][2], int current, int seen[], int order[], int *count) {
    seen[current] = 1;
    order[*count] = current;
    (*count)++;
    for (int i = 0; i < 2; i++) {
        int next = graph[current][i];
        if (!seen[next]) visit(graph, next, seen, order, count);
    }
}

int main(void) {
    int graph[4][2] = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    int seen[4] = {0};
    int order[4];
    int count = 0;
    visit(graph, 0, seen, order, &count);
    for (int i = 0; i < count; i++) {
        if (i > 0) printf(" ");
        printf("%d", order[i]);
    }
    printf("\n");
    return 0;
}
