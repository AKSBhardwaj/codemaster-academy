def partition(a, low, high):
    pivot = a[high]
    place = low
    for i in range(low, high):
        if a[i] <= pivot:
            a[i], a[place] = a[place], a[i]
            place += 1
    a[place], a[high] = a[high], a[place]
    return place

def quick_sort(a, low, high):
    if low >= high:
        return
    pivot_position = partition(a, low, high)
    quick_sort(a, low, pivot_position - 1)
    quick_sort(a, pivot_position + 1, high)

a = [4, 2, 3, 1]
quick_sort(a, 0, len(a) - 1)
print(*a)
