scores = [3, 6, 9]
target = 9
checks = 0
for score in scores:
    checks += 1
    if score == target:
        break
print(checks)
