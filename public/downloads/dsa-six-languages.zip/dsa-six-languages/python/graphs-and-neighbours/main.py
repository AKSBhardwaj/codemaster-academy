edges = [
    [0, 1, 1],
    [1, 0, 0],
    [1, 0, 0]
]
vertex = 0
if 0 <= vertex < len(edges):
    for neighbour in range(len(edges)):
        if edges[vertex][neighbour] == 1:
            print(neighbour)
