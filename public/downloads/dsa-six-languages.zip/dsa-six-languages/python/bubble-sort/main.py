a = [4, 2, 3, 1]
n = len(a)
for end in range(n - 1, 0, -1):
    swapped = False
    for i in range(end):
        if a[i] > a[i + 1]:
            a[i], a[i + 1] = a[i + 1], a[i]
            swapped = True
    if not swapped:
        break
print(*a)
