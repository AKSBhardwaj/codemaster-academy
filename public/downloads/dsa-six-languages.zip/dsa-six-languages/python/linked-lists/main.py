class Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node

head = Node(3, Node(6, Node(9)))
current = head
while current is not None:
    print(current.value)
    current = current.next
