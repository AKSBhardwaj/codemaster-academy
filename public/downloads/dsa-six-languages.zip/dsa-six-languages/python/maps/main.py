books = {2: 3, 5: 1}
books[2] = 6
if 2 in books:
    print(books[2])
print(len(books))
