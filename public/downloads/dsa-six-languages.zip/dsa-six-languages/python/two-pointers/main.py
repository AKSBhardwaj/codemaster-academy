a = [1, 2, 4, 6, 8]
target = 10
left, right = 0, len(a) - 1
found = False
while left < right:
    total = a[left] + a[right]
    if total == target:
        found = True
        break
    if total < target:
        left += 1
    else:
        right -= 1
if found:
    print(left, right)
else:
    print("not found")
