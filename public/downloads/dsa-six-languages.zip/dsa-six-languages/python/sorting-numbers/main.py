a = [10, 2, 30]
a.sort()
print(*a)
