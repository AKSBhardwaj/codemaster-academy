cards = {4, 4, 7}
print(len(cards))
print(1 if 7 in cards else 0)
