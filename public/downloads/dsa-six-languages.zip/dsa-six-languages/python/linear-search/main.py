def find_first(a, target):
    for i in range(len(a)):
        if a[i] == target:
            return i
    return -1

a = [9, 4, 7, 4]
print(find_first(a, 7))
print(find_first(a, 6))
