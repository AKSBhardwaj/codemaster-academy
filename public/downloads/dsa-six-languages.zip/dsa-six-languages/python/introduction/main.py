scores = [4, 7, 2]
total = 0
for score in scores:
    total += score
print(total)
