n = 4
ways = [0] * (n + 1)
ways[0] = 1
for step in range(1, n + 1):
    ways[step] = ways[step - 1]
    if step >= 2:
        ways[step] += ways[step - 2]
print(ways[n])
