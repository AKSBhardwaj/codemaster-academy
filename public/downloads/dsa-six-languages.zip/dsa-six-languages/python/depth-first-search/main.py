graph = [[1, 2], [0, 3], [0, 3], [1, 2]]
seen = [False] * len(graph)
order = []

def visit(current):
    seen[current] = True
    order.append(current)
    for next_node in graph[current]:
        if not seen[next_node]:
            visit(next_node)

visit(0)
print(*order)
