from collections import deque

queue = deque()
queue.append(10)
queue.append(20)
if queue:
    print(queue.popleft())
if queue:
    print(queue[0])
