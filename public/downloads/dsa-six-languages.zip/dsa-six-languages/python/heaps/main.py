heap = [2, 4, 7, 9]
size = len(heap)
if size > 0:
    removed = heap[0]
    heap[0] = heap[size - 1]
    size -= 1
    parent = 0
    while 2 * parent + 1 < size:
        child = 2 * parent + 1
        right = child + 1
        if right < size and heap[right] < heap[child]:
            child = right
        if heap[parent] <= heap[child]:
            break
        heap[parent], heap[child] = heap[child], heap[parent]
        parent = child
    print(removed)
    if size > 0:
        print(heap[0])
