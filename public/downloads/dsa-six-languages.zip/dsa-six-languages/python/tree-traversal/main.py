class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def inorder(node, order):
    if node is None:
        return
    inorder(node.left, order)
    order.append(node.value)
    inorder(node.right, order)

root = Node(4, Node(2, Node(1), Node(3)), Node(6))
order = []
inorder(root, order)
print(*order)
