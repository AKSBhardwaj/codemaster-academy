print(4 + 7 + 2)
