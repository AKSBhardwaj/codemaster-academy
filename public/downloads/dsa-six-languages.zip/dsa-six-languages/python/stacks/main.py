stack = []
stack.append(10)
stack.append(20)
if stack:
    print(stack.pop())
if stack:
    print(stack[-1])
