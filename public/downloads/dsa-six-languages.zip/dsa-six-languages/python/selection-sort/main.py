a = [4, 2, 3, 1]
n = len(a)
for start in range(n - 1):
    smallest = start
    for i in range(start + 1, n):
        if a[i] < a[smallest]:
            smallest = i
    a[start], a[smallest] = a[smallest], a[start]
print(*a)
