scores = [4, 7, 2]
index = 1
if 0 <= index < len(scores):
    scores[index] = 9
    print(scores[index])
