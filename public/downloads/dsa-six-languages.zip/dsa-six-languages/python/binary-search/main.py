def binary_search(a, target):
    low = 0
    high = len(a) - 1
    while low <= high:
        mid = low + (high - low) // 2
        if a[mid] == target:
            return mid
        if a[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

a = [2, 4, 6, 8, 10]
print(binary_search(a, 8))
print(binary_search(a, 7))
