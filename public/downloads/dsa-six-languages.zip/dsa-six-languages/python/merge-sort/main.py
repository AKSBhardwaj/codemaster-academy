def merge_sort(a, buffer, left, right):
    if left >= right:
        return
    mid = left + (right - left) // 2
    merge_sort(a, buffer, left, mid)
    merge_sort(a, buffer, mid + 1, right)
    i, j, k = left, mid + 1, left
    while i <= mid and j <= right:
        if a[i] <= a[j]:
            buffer[k] = a[i]
            i += 1
        else:
            buffer[k] = a[j]
            j += 1
        k += 1
    while i <= mid:
        buffer[k] = a[i]
        i += 1
        k += 1
    while j <= right:
        buffer[k] = a[j]
        j += 1
        k += 1
    for pos in range(left, right + 1):
        a[pos] = buffer[pos]

a = [4, 2, 3, 1]
buffer = [0] * len(a)
merge_sort(a, buffer, 0, len(a) - 1)
print(*a)
