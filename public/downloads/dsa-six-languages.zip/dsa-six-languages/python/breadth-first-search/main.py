graph = [[1, 2], [0, 3], [0, 3], [1, 2]]
seen = [False] * len(graph)
queue = [0]
seen[0] = True
head = 0
while head < len(queue):
    current = queue[head]
    head += 1
    for next_node in graph[current]:
        if not seen[next_node]:
            seen[next_node] = True
            queue.append(next_node)
print(*queue)
