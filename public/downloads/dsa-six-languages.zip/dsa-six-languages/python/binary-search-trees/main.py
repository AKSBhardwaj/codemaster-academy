class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

root = Node(8, Node(3), Node(10))
current = root
target = 10
found = -1
while current is not None:
    if target == current.value:
        found = current.value
        break
    current = current.left if target < current.value else current.right
print(found)
