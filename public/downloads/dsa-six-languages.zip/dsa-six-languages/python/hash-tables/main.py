keys = [0] * 4
values = [0] * 4
used = [False] * 4
inputs = [5, 9]
amounts = [20, 40]
for i in range(len(inputs)):
    for step in range(4):
        slot = (inputs[i] % 4 + step) % 4
        if not used[slot] or keys[slot] == inputs[i]:
            used[slot] = True
            keys[slot] = inputs[i]
            values[slot] = amounts[i]
            break
target = 9
for step in range(4):
    slot = (target % 4 + step) % 4
    if not used[slot]:
        break
    if keys[slot] == target:
        print(values[slot])
        break
