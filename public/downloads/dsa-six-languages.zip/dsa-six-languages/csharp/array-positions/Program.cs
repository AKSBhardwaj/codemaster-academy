int[] scores = { 4, 7, 2 };
int index = 1;
if (index >= 0 && index < scores.Length)
{
    scores[index] = 9;
    System.Console.WriteLine(scores[index]);
}
