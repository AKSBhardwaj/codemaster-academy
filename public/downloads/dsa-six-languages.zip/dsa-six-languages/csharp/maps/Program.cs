var books = new System.Collections.Generic.Dictionary<int, int>
{
    [2] = 3,
    [5] = 1
};
books[2] = 6;
if (books.TryGetValue(2, out int count)) System.Console.WriteLine(count);
System.Console.WriteLine(books.Count);
