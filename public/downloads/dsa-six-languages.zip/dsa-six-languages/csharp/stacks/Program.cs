var stack = new System.Collections.Generic.Stack<int>();
stack.Push(10);
stack.Push(20);
if (stack.Count > 0) System.Console.WriteLine(stack.Pop());
if (stack.Count > 0) System.Console.WriteLine(stack.Peek());
