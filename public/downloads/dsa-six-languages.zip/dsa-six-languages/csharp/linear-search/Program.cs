using System;
using System.Collections.Generic;

int[] a = {9, 4, 7, 4};
Console.WriteLine(FindFirst(a, 7));
Console.WriteLine(FindFirst(a, 6));

static int FindFirst(int[] a, int target) {
    int n = a.Length;
    for (int i = 0; i < n; i++) {
        if (a[i] == target) return i;
    }
    return -1;
}
