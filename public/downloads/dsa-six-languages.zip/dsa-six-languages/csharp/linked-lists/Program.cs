Node head = new Node(3, new Node(6, new Node(9, null)));
Node? current = head;
while (current is not null)
{
    System.Console.WriteLine(current.Value);
    current = current.Next;
}

class Node
{
    public int Value;
    public Node? Next;
    public Node(int value, Node? next) { Value = value; Next = next; }
}
