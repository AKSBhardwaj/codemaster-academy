using System;
using System.Collections.Generic;

int[][] graph = {
    new int[] {1, 2}, new int[] {0, 3},
    new int[] {0, 3}, new int[] {1, 2}
};
bool[] seen = new bool[graph.Length];
List<int> queue = new List<int> {0};
seen[0] = true;
int head = 0;
while (head < queue.Count) {
    int current = queue[head++];
    foreach (int next in graph[current]) {
        if (!seen[next]) {
            seen[next] = true;
            queue.Add(next);
        }
    }
}
Console.WriteLine(string.Join(" ", queue));
