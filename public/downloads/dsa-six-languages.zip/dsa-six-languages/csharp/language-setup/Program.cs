System.Console.WriteLine(4 + 7 + 2);
