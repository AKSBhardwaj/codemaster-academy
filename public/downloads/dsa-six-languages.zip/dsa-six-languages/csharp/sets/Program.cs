var cards = new System.Collections.Generic.HashSet<int> { 4, 4, 7 };
System.Console.WriteLine(cards.Count);
System.Console.WriteLine(cards.Contains(7) ? 1 : 0);
