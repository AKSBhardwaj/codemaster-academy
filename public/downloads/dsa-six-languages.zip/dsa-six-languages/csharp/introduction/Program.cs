int[] scores = { 4, 7, 2 };
int total = 0;
foreach (int score in scores)
{
    total += score;
}
System.Console.WriteLine(total);
