using System;
using System.Collections.Generic;

int[] a = {10, 2, 30};
Array.Sort(a);
Console.WriteLine(string.Join(" ", a));
