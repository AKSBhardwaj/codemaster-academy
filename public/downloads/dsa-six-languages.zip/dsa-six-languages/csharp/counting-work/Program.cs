int[] scores = { 3, 6, 9 };
int target = 9;
int checks = 0;
foreach (int score in scores)
{
    checks++;
    if (score == target) break;
}
System.Console.WriteLine(checks);
