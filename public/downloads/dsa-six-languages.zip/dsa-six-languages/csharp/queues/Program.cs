var queue = new System.Collections.Generic.Queue<int>();
queue.Enqueue(10);
queue.Enqueue(20);
if (queue.Count > 0) System.Console.WriteLine(queue.Dequeue());
if (queue.Count > 0) System.Console.WriteLine(queue.Peek());
