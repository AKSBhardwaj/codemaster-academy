using System;
using System.Collections.Generic;

Console.WriteLine(SumTo(4));
Console.WriteLine(SumTo(0));

static int SumTo(int n) {
    if (n == 0) return 0;
    return n + SumTo(n - 1);
}
