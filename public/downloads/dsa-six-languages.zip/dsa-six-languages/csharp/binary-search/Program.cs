using System;
using System.Collections.Generic;

int[] a = {2, 4, 6, 8, 10};
Console.WriteLine(BinarySearch(a, 8));
Console.WriteLine(BinarySearch(a, 7));

static int BinarySearch(int[] a, int target) {
    int n = a.Length;
    int low = 0;
    int high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}
