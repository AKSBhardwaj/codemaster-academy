using System;
using System.Collections.Generic;

int[] a = {4, 2, 3, 1};
QuickSort(a, 0, a.Length - 1);
Console.WriteLine(string.Join(" ", a));

static int Partition(int[] a, int low, int high) {
    int pivot = a[high];
    int place = low;
    for (int i = low; i < high; i++) {
        if (a[i] <= pivot) {
            int temp = a[i];
            a[i] = a[place];
            a[place] = temp;
            place++;
        }
    }
    int pivotTemp = a[place];
    a[place] = a[high];
    a[high] = pivotTemp;
    return place;
}

static void QuickSort(int[] a, int low, int high) {
    if (low >= high) return;
    int pivotPosition = Partition(a, low, high);
    QuickSort(a, low, pivotPosition - 1);
    QuickSort(a, pivotPosition + 1, high);
}
