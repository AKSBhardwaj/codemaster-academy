Node root = new Node(8, new Node(3), new Node(10));
System.Console.WriteLine(Sum(root));

static int Sum(Node? node)
{
    if (node is null) return 0;
    return node.Value + Sum(node.Left) + Sum(node.Right);
}

class Node
{
    public int Value;
    public Node? Left, Right;
    public Node(int value, Node? left = null, Node? right = null)
    { Value = value; Left = left; Right = right; }
}
