using System;
using System.Collections.Generic;

int[] a = {1, 2, 4, 6, 8};
int target = 10;
int n = a.Length;
int left = 0, right = n - 1;
bool found = false;
while (left < right) {
    int sum = a[left] + a[right];
    if (sum == target) {
        found = true;
        break;
    }
    if (sum < target) left++;
    else right--;
}
Console.WriteLine(found ? $"{left} {right}" : "not found");
