using System;
using System.Collections.Generic;

int[] a = {4, 2, 3, 1};
int n = a.Length;
for (int start = 0; start < n - 1; start++) {
    int smallest = start;
    for (int i = start + 1; i < n; i++) {
        if (a[i] < a[smallest]) smallest = i;
    }
    int temp = a[start];
    a[start] = a[smallest];
    a[smallest] = temp;
}
Console.WriteLine(string.Join(" ", a));
