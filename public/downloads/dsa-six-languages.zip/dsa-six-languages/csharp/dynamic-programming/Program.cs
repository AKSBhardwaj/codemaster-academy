using System;
using System.Collections.Generic;

int n = 4;
int[] ways = new int[n + 1];
ways[0] = 1;
for (int step = 1; step <= n; step++) {
    ways[step] = ways[step - 1];
    if (step >= 2) ways[step] += ways[step - 2];
}
Console.WriteLine(ways[n]);
