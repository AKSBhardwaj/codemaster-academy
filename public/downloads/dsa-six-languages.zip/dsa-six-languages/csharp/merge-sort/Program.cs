using System;
using System.Collections.Generic;

int[] a = {4, 2, 3, 1};
int[] buffer = new int[a.Length];
MergeSort(a, buffer, 0, a.Length - 1);
Console.WriteLine(string.Join(" ", a));

static void MergeSort(int[] a, int[] buffer, int left, int right) {
    if (left >= right) return;
    int mid = left + (right - left) / 2;
    MergeSort(a, buffer, left, mid);
    MergeSort(a, buffer, mid + 1, right);
    int i = left, j = mid + 1, k = left;
    while (i <= mid && j <= right) {
        if (a[i] <= a[j]) buffer[k++] = a[i++];
        else buffer[k++] = a[j++];
    }
    while (i <= mid) buffer[k++] = a[i++];
    while (j <= right) buffer[k++] = a[j++];
    for (int pos = left; pos <= right; pos++) a[pos] = buffer[pos];
}
