using System;
using System.Collections.Generic;

int[][] graph = {
    new int[] {1, 2}, new int[] {0, 3},
    new int[] {0, 3}, new int[] {1, 2}
};
bool[] seen = new bool[graph.Length];
List<int> order = new List<int>();
Visit(graph, 0, seen, order);
Console.WriteLine(string.Join(" ", order));

static void Visit(int[][] graph, int current, bool[] seen, List<int> order) {
    seen[current] = true;
    order.Add(current);
    foreach (int next in graph[current]) {
        if (!seen[next]) Visit(graph, next, seen, order);
    }
}
