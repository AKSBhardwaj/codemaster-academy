using System;
using System.Collections.Generic;

int[] a = {4, 2, 3, 1};
int n = a.Length;
for (int end = n - 1; end > 0; end--) {
    bool swapped = false;
    for (int i = 0; i < end; i++) {
        if (a[i] > a[i + 1]) {
            int temp = a[i];
            a[i] = a[i + 1];
            a[i + 1] = temp;
            swapped = true;
        }
    }
    if (!swapped) break;
}
Console.WriteLine(string.Join(" ", a));
