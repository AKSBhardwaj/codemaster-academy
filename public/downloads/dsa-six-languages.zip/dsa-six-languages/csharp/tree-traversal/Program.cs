using System;
using System.Collections.Generic;

Node root = new Node(4, new Node(2, new Node(1), new Node(3)), new Node(6));
List<int> order = new List<int>();
Inorder(root, order);
Console.WriteLine(string.Join(" ", order));

static void Inorder(Node? node, List<int> order) {
    if (node is null) return;
    Inorder(node.Left, order);
    order.Add(node.Value);
    Inorder(node.Right, order);
}

class Node {
    public int Value;
    public Node? Left;
    public Node? Right;

    public Node(int value, Node? left = null, Node? right = null) {
        Value = value;
        Left = left;
        Right = right;
    }
}
