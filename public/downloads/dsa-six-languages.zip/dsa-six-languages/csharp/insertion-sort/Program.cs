using System;
using System.Collections.Generic;

int[] a = {4, 2, 3, 1};
int n = a.Length;
for (int i = 1; i < n; i++) {
    int key = a[i];
    int j = i - 1;
    while (j >= 0 && a[j] > key) {
        a[j + 1] = a[j];
        j--;
    }
    a[j + 1] = key;
}
Console.WriteLine(string.Join(" ", a));
