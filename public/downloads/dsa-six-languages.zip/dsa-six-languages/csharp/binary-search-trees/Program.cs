Node root = new Node(8, new Node(3), new Node(10));
Node? current = root;
int target = 10;
int found = -1;
while (current != null) {
    if (target == current.Value) {
        found = current.Value;
        break;
    }
    current = target < current.Value ? current.Left : current.Right;
}
System.Console.WriteLine(found);

class Node
{
    public int Value;
    public Node? Left, Right;
    public Node(int value, Node? left = null, Node? right = null)
    { Value = value; Left = left; Right = right; }
}
