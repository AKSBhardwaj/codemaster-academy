import java.util.*;

class Main {
    static class Node {
        int value;
        Node left, right;

        Node(int value, Node left, Node right) {
            this.value = value;
            this.left = left;
            this.right = right;
        }
    }

    static void inorder(Node node, List<Integer> order) {
        if (node == null) return;
        inorder(node.left, order);
        order.add(node.value);
        inorder(node.right, order);
    }

    public static void main(String[] args) {
        Node root = new Node(4,
            new Node(2, new Node(1, null, null), new Node(3, null, null)),
            new Node(6, null, null));
        List<Integer> order = new ArrayList<>();
        inorder(root, order);
        for (int i = 0; i < order.size(); i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(order.get(i));
        }
        System.out.println();
    }
}
