import java.util.*;

class Main {
    static int partition(int[] a, int low, int high) {
        int pivot = a[high];
        int place = low;
        for (int i = low; i < high; i++) {
            if (a[i] <= pivot) {
                int temp = a[i];
                a[i] = a[place];
                a[place] = temp;
                place++;
            }
        }
        int pivotTemp = a[place];
        a[place] = a[high];
        a[high] = pivotTemp;
        return place;
    }

    static void quickSort(int[] a, int low, int high) {
        if (low >= high) return;
        int pivotPosition = partition(a, low, high);
        quickSort(a, low, pivotPosition - 1);
        quickSort(a, pivotPosition + 1, high);
    }

    public static void main(String[] args) {
        int[] a = {4, 2, 3, 1};
        int n = a.length;
        quickSort(a, 0, n - 1);
        for (int i = 0; i < n; i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(a[i]);
        }
        System.out.println();
    }
}
