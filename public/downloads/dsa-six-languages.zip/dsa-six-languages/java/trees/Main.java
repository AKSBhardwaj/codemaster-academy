public class Main {
    static class Node {
        int value;
        Node left, right;
        Node(int value, Node left, Node right) {
            this.value = value; this.left = left; this.right = right;
        }
    }
    static int sum(Node node) {
        if (node == null) return 0;
        return node.value + sum(node.left) + sum(node.right);
    }
    public static void main(String[] args) {
        Node root = new Node(8, new Node(3, null, null), new Node(10, null, null));
        System.out.println(sum(root));
    }
}
