import java.util.*;

class Main {
    public static void main(String[] args) {
        int[] a = {10, 2, 30};
        int n = a.length;
        Arrays.sort(a);
        for (int i = 0; i < n; i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(a[i]);
        }
        System.out.println();
    }
}
