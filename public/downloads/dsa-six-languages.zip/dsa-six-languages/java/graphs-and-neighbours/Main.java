public class Main {
    public static void main(String[] args) {
        int[][] edges = {{0, 1, 1}, {1, 0, 0}, {1, 0, 0}};
        int vertex = 0;
        if (vertex >= 0 && vertex < edges.length) {
            for (int neighbour = 0; neighbour < edges.length; neighbour++) {
                if (edges[vertex][neighbour] == 1) System.out.println(neighbour);
            }
        }
    }
}
