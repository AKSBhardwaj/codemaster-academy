import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<Integer, Integer> books = new HashMap<>();
        books.put(2, 3);
        books.put(5, 1);
        books.put(2, 6);
        if (books.containsKey(2)) System.out.println(books.get(2));
        System.out.println(books.size());
    }
}
