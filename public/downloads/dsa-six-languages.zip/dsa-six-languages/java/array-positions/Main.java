public class Main {
    public static void main(String[] args) {
        int[] scores = {4, 7, 2};
        int index = 1;
        if (index >= 0 && index < scores.length) {
            scores[index] = 9;
            System.out.println(scores[index]);
        }
    }
}
