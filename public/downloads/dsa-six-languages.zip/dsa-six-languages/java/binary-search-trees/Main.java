public class Main {
    static class Node {
        int value;
        Node left, right;
        Node(int value, Node left, Node right) {
            this.value = value; this.left = left; this.right = right;
        }
    }
    public static void main(String[] args) {
        Node root = new Node(8, new Node(3, null, null), new Node(10, null, null));
        Node current = root;
        int target = 10;
        int found = -1;
        while (current != null) {
            if (target == current.value) {
                found = current.value;
                break;
            }
            current = target < current.value ? current.left : current.right;
        }
        System.out.println(found);
    }
}
