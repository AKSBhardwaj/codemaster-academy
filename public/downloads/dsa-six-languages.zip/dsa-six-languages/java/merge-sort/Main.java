import java.util.*;

class Main {
    static void mergeSort(int[] a, int[] buffer, int left, int right) {
        if (left >= right) return;
        int mid = left + (right - left) / 2;
        mergeSort(a, buffer, left, mid);
        mergeSort(a, buffer, mid + 1, right);
        int i = left, j = mid + 1, k = left;
        while (i <= mid && j <= right) {
            if (a[i] <= a[j]) buffer[k++] = a[i++];
            else buffer[k++] = a[j++];
        }
        while (i <= mid) buffer[k++] = a[i++];
        while (j <= right) buffer[k++] = a[j++];
        for (int pos = left; pos <= right; pos++) a[pos] = buffer[pos];
    }

    public static void main(String[] args) {
        int[] a = {4, 2, 3, 1};
        int n = a.length;
        int[] buffer = new int[n];
        mergeSort(a, buffer, 0, n - 1);
        for (int i = 0; i < n; i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(a[i]);
        }
        System.out.println();
    }
}
