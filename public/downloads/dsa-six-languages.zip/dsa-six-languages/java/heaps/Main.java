public class Main {
    public static void main(String[] args) {
        int[] heap = {2, 4, 7, 9};
        int size = 4;
        if (size > 0) {
            int removed = heap[0];
            heap[0] = heap[size - 1];
            size--;
            int parent = 0;
            while (2 * parent + 1 < size) {
                int child = 2 * parent + 1;
                int right = child + 1;
                if (right < size && heap[right] < heap[child]) child = right;
                if (heap[parent] <= heap[child]) break;
                int temp = heap[parent];
                heap[parent] = heap[child];
                heap[child] = temp;
                parent = child;
            }
            System.out.println(removed);
            if (size > 0) System.out.println(heap[0]);
        }
    }
}
