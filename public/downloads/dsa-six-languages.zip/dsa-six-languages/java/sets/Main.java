import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        HashSet<Integer> cards = new HashSet<>();
        cards.add(4);
        cards.add(4);
        cards.add(7);
        System.out.println(cards.size());
        System.out.println(cards.contains(7) ? 1 : 0);
    }
}
