import java.util.*;

class Main {
    public static void main(String[] args) {
        int[][] graph = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
        boolean[] seen = new boolean[graph.length];
        List<Integer> queue = new ArrayList<>();
        queue.add(0);
        seen[0] = true;
        int head = 0;
        while (head < queue.size()) {
            int current = queue.get(head++);
            for (int next : graph[current]) {
                if (!seen[next]) {
                    seen[next] = true;
                    queue.add(next);
                }
            }
        }
        for (int i = 0; i < queue.size(); i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(queue.get(i));
        }
        System.out.println();
    }
}
