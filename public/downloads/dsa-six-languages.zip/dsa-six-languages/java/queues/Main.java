import java.util.ArrayDeque;

public class Main {
    public static void main(String[] args) {
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        queue.addLast(10);
        queue.addLast(20);
        if (!queue.isEmpty()) System.out.println(queue.removeFirst());
        if (!queue.isEmpty()) System.out.println(queue.peekFirst());
    }
}
