import java.util.ArrayDeque;

public class Main {
    public static void main(String[] args) {
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        stack.push(10);
        stack.push(20);
        if (!stack.isEmpty()) System.out.println(stack.pop());
        if (!stack.isEmpty()) System.out.println(stack.peek());
    }
}
