import java.util.*;

class Main {
    static int findFirst(int[] a, int target) {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            if (a[i] == target) return i;
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] a = {9, 4, 7, 4};
        System.out.println(findFirst(a, 7));
        System.out.println(findFirst(a, 6));
    }
}
