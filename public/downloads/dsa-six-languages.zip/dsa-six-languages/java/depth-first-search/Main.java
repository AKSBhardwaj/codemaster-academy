import java.util.*;

class Main {
    static void visit(int[][] graph, int current, boolean[] seen, List<Integer> order) {
        seen[current] = true;
        order.add(current);
        for (int next : graph[current]) {
            if (!seen[next]) visit(graph, next, seen, order);
        }
    }

    public static void main(String[] args) {
        int[][] graph = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
        boolean[] seen = new boolean[graph.length];
        List<Integer> order = new ArrayList<>();
        visit(graph, 0, seen, order);
        for (int i = 0; i < order.size(); i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(order.get(i));
        }
        System.out.println();
    }
}
