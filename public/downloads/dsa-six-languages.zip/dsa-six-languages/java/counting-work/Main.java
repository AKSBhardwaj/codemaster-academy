public class Main {
    public static void main(String[] args) {
        int[] scores = {3, 6, 9};
        int target = 9;
        int checks = 0;
        for (int score : scores) {
            checks++;
            if (score == target) break;
        }
        System.out.println(checks);
    }
}
