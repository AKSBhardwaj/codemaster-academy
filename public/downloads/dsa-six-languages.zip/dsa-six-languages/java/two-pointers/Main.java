import java.util.*;

class Main {
    public static void main(String[] args) {
        int[] a = {1, 2, 4, 6, 8};
        int target = 10;
        int n = a.length;
        int left = 0, right = n - 1;
        boolean found = false;
        while (left < right) {
            int sum = a[left] + a[right];
            if (sum == target) {
                found = true;
                break;
            }
            if (sum < target) left++;
            else right--;
        }
        System.out.println(found ? left + " " + right : "not found");
    }
}
