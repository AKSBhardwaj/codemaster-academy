import java.util.*;

class Main {
    public static void main(String[] args) {
        int[] a = {4, 2, 3, 1};
        int n = a.length;
        for (int start = 0; start < n - 1; start++) {
            int smallest = start;
            for (int i = start + 1; i < n; i++) {
                if (a[i] < a[smallest]) smallest = i;
            }
            int temp = a[start];
            a[start] = a[smallest];
            a[smallest] = temp;
        }
        for (int i = 0; i < n; i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(a[i]);
        }
        System.out.println();
    }
}
