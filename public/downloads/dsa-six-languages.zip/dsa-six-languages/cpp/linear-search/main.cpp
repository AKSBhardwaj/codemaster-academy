#include <algorithm>
#include <iostream>
#include <vector>

int findFirst(const std::vector<int>& a, int target) {
    int n = static_cast<int>(a.size());
    for (int i = 0; i < n; i++) {
        if (a[i] == target) return i;
    }
    return -1;
}

int main() {
    std::vector<int> a = {9, 4, 7, 4};
    std::cout << findFirst(a, 7) << "\n";
    std::cout << findFirst(a, 6) << "\n";
    return 0;
}
