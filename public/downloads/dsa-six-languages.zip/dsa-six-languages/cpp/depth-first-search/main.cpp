#include <algorithm>
#include <iostream>
#include <vector>

void visit(const std::vector<std::vector<int>>& graph, int current,
           std::vector<bool>& seen, std::vector<int>& order) {
    seen[current] = true;
    order.push_back(current);
    for (int next : graph[current]) {
        if (!seen[next]) visit(graph, next, seen, order);
    }
}

int main() {
    std::vector<std::vector<int>> graph = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    std::vector<bool> seen(graph.size(), false);
    std::vector<int> order;
    visit(graph, 0, seen, order);
    for (int i = 0; i < static_cast<int>(order.size()); i++) {
        if (i > 0) std::cout << " ";
        std::cout << order[i];
    }
    std::cout << "\n";
    return 0;
}
