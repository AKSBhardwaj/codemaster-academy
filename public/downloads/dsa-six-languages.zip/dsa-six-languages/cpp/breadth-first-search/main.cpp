#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<std::vector<int>> graph = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    std::vector<bool> seen(graph.size(), false);
    std::vector<int> queue = {0};
    seen[0] = true;
    int head = 0;
    while (head < static_cast<int>(queue.size())) {
        int current = queue[head++];
        for (int next : graph[current]) {
            if (!seen[next]) {
                seen[next] = true;
                queue.push_back(next);
            }
        }
    }
    for (int i = 0; i < static_cast<int>(queue.size()); i++) {
        if (i > 0) std::cout << " ";
        std::cout << queue[i];
    }
    std::cout << "\n";
    return 0;
}
