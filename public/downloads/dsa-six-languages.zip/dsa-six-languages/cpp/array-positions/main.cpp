#include <iostream>

int main() {
    int scores[] = {4, 7, 2};
    int length = 3;
    int index = 1;
    if (index >= 0 && index < length) {
        scores[index] = 9;
        std::cout << scores[index] << '\n';
    }
    return 0;
}
