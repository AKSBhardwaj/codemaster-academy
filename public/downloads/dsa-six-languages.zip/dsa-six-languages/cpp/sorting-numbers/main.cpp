#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> a = {10, 2, 30};
    int n = static_cast<int>(a.size());
    std::sort(a.begin(), a.end());
    for (int i = 0; i < n; i++) {
        if (i > 0) std::cout << " ";
        std::cout << a[i];
    }
    std::cout << "\n";
    return 0;
}
