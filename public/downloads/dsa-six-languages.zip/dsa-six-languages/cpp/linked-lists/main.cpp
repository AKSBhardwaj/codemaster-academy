#include <iostream>
struct Node { int value; Node* next; };

int main() {
    Node last{9, nullptr};
    Node middle{6, &last};
    Node first{3, &middle};
    Node* head = &first;
    Node* current = head;
    while (current != nullptr) {
        std::cout << current->value << '\n';
        current = current->next;
    }
    return 0;
}
