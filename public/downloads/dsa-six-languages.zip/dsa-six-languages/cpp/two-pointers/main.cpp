#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> a = {1, 2, 4, 6, 8};
    int target = 10;
    int n = static_cast<int>(a.size());
    int left = 0, right = n - 1;
    bool found = false;
    while (left < right) {
        int sum = a[left] + a[right];
        if (sum == target) {
            found = true;
            break;
        }
        if (sum < target) left++;
        else right--;
    }
    if (found) std::cout << left << " " << right << "\n";
    else std::cout << "not found\n";
    return 0;
}
