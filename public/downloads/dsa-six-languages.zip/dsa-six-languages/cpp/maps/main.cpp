#include <iostream>
#include <map>

int main() {
    std::map<int, int> books = {{2, 3}, {5, 1}};
    books[2] = 6;
    auto found = books.find(2);
    if (found != books.end()) std::cout << found->second << '\n';
    std::cout << books.size() << '\n';
    return 0;
}
