#include <iostream>
struct Node { int value; Node* left; Node* right; };

int main() {
    Node left{3, nullptr, nullptr};
    Node right{10, nullptr, nullptr};
    Node root{8, &left, &right};
    Node* current = &root;
    int target = 10;
    int found = -1;
    while (current != nullptr) {
        if (target == current->value) {
            found = current->value;
            break;
        }
        current = target < current->value ? current->left : current->right;
    }
    std::cout << found << '\n';
    return 0;
}
