#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    int n = 4;
    std::vector<int> ways(n + 1, 0);
    ways[0] = 1;
    for (int step = 1; step <= n; step++) {
        ways[step] = ways[step - 1];
        if (step >= 2) ways[step] += ways[step - 2];
    }
    std::cout << ways[n] << "\n";
    return 0;
}
