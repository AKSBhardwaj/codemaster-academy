#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> a = {4, 2, 3, 1};
    int n = static_cast<int>(a.size());
    for (int end = n - 1; end > 0; end--) {
        bool swapped = false;
        for (int i = 0; i < end; i++) {
            if (a[i] > a[i + 1]) {
                int temp = a[i];
                a[i] = a[i + 1];
                a[i + 1] = temp;
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    for (int i = 0; i < n; i++) {
        if (i > 0) std::cout << " ";
        std::cout << a[i];
    }
    std::cout << "\n";
    return 0;
}
