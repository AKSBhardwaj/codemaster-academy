#include <iostream>

int main() {
    int scores[] = {3, 6, 9};
    int target = 9;
    int checks = 0;
    for (int score : scores) {
        checks++;
        if (score == target) break;
    }
    std::cout << checks << '\n';
    return 0;
}
