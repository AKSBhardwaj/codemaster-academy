#include <algorithm>
#include <iostream>
#include <vector>

struct Node {
    int value;
    Node *left;
    Node *right;
};

void inorder(const Node *node, std::vector<int>& order) {
    if (node == nullptr) return;
    inorder(node->left, order);
    order.push_back(node->value);
    inorder(node->right, order);
}

int main() {
    Node one{1, nullptr, nullptr};
    Node three{3, nullptr, nullptr};
    Node two{2, &one, &three};
    Node six{6, nullptr, nullptr};
    Node root{4, &two, &six};
    std::vector<int> order;
    inorder(&root, order);
    for (int i = 0; i < static_cast<int>(order.size()); i++) {
        if (i > 0) std::cout << " ";
        std::cout << order[i];
    }
    std::cout << "\n";
    return 0;
}
