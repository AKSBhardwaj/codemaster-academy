#include <algorithm>
#include <iostream>
#include <vector>

int binarySearch(const std::vector<int>& a, int target) {
    int n = static_cast<int>(a.size());
    int low = 0;
    int high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

int main() {
    std::vector<int> a = {2, 4, 6, 8, 10};
    std::cout << binarySearch(a, 8) << "\n";
    std::cout << binarySearch(a, 7) << "\n";
    return 0;
}
