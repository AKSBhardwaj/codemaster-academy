#include <iostream>
#include <queue>

int main() {
    std::queue<int> queue;
    queue.push(10);
    queue.push(20);
    if (!queue.empty()) {
        std::cout << queue.front() << '\n';
        queue.pop();
    }
    if (!queue.empty()) std::cout << queue.front() << '\n';
    return 0;
}
