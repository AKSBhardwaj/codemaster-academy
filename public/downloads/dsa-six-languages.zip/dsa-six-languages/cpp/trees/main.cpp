#include <iostream>
struct Node { int value; Node* left; Node* right; };
int sum(const Node* node) {
    if (node == nullptr) return 0;
    return node->value + sum(node->left) + sum(node->right);
}

int main() {
    Node left{3, nullptr, nullptr};
    Node right{10, nullptr, nullptr};
    Node root{8, &left, &right};
    std::cout << sum(&root) << '\n';
    return 0;
}
