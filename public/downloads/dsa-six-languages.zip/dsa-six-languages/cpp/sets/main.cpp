#include <iostream>
#include <set>

int main() {
    std::set<int> cards = {4, 4, 7};
    std::cout << cards.size() << '\n';
    std::cout << (cards.count(7) > 0 ? 1 : 0) << '\n';
    return 0;
}
