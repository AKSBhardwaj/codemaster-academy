#include <iostream>

int main() {
    int keys[4] = {0};
    int values[4] = {0};
    int used[4] = {0};
    int inputs[] = {5, 9};
    int amounts[] = {20, 40};
    for (int i = 0; i < 2; i++) {
        for (int step = 0; step < 4; step++) {
            int slot = (inputs[i] % 4 + step) % 4;
            if (!used[slot] || keys[slot] == inputs[i]) {
                used[slot] = 1;
                keys[slot] = inputs[i];
                values[slot] = amounts[i];
                break;
            }
        }
    }
    int target = 9;
    for (int step = 0; step < 4; step++) {
        int slot = (target % 4 + step) % 4;
        if (!used[slot]) break;
        if (keys[slot] == target) {
            std::cout << values[slot] << '\n';
            break;
        }
    }
    return 0;
}
