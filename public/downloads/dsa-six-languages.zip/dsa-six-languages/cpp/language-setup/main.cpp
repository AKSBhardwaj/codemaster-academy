#include <iostream>

int main() {
    std::cout << 4 + 7 + 2 << '\n';
    return 0;
}
