#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> a = {4, 2, 3, 1};
    int n = static_cast<int>(a.size());
    for (int start = 0; start < n - 1; start++) {
        int smallest = start;
        for (int i = start + 1; i < n; i++) {
            if (a[i] < a[smallest]) smallest = i;
        }
        int temp = a[start];
        a[start] = a[smallest];
        a[smallest] = temp;
    }
    for (int i = 0; i < n; i++) {
        if (i > 0) std::cout << " ";
        std::cout << a[i];
    }
    std::cout << "\n";
    return 0;
}
