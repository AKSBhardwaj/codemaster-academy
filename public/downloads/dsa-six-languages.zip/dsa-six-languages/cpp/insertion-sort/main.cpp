#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> a = {4, 2, 3, 1};
    int n = static_cast<int>(a.size());
    for (int i = 1; i < n; i++) {
        int key = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] > key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
    for (int i = 0; i < n; i++) {
        if (i > 0) std::cout << " ";
        std::cout << a[i];
    }
    std::cout << "\n";
    return 0;
}
