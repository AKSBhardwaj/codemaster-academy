#include <algorithm>
#include <iostream>
#include <vector>

int partition(std::vector<int>& a, int low, int high) {
    int pivot = a[high];
    int place = low;
    for (int i = low; i < high; i++) {
        if (a[i] <= pivot) {
            int temp = a[i];
            a[i] = a[place];
            a[place] = temp;
            place++;
        }
    }
    int pivotTemp = a[place];
    a[place] = a[high];
    a[high] = pivotTemp;
    return place;
}

void quickSort(std::vector<int>& a, int low, int high) {
    if (low >= high) return;
    int pivotPosition = partition(a, low, high);
    quickSort(a, low, pivotPosition - 1);
    quickSort(a, pivotPosition + 1, high);
}

int main() {
    std::vector<int> a = {4, 2, 3, 1};
    int n = static_cast<int>(a.size());
    quickSort(a, 0, n - 1);
    for (int i = 0; i < n; i++) {
        if (i > 0) std::cout << " ";
        std::cout << a[i];
    }
    std::cout << "\n";
    return 0;
}
