#include <iostream>

int main() {
    int scores[] = {4, 7, 2};
    int total = 0;
    for (int score : scores) {
        total += score;
    }
    std::cout << total << '\n';
    return 0;
}
