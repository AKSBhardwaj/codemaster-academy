#include <iostream>
#include <stack>

int main() {
    std::stack<int> stack;
    stack.push(10);
    stack.push(20);
    if (!stack.empty()) {
        std::cout << stack.top() << '\n';
        stack.pop();
    }
    if (!stack.empty()) std::cout << stack.top() << '\n';
    return 0;
}
