const scores = [4, 7, 2];
const index = 1;
if (index >= 0 && index < scores.length) {
  scores[index] = 9;
  console.log(scores[index]);
}
