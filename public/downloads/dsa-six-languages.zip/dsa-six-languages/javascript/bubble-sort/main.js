const a = [4, 2, 3, 1];
const n = a.length;
for (let end = n - 1; end > 0; end--) {
    let swapped = false;
    for (let i = 0; i < end; i++) {
        if (a[i] > a[i + 1]) {
            let temp = a[i];
            a[i] = a[i + 1];
            a[i + 1] = temp;
            swapped = true;
        }
    }
    if (!swapped) break;
}
console.log(a.join(" "));
