const a = [10, 2, 30];
a.sort((left, right) => left - right);
console.log(a.join(" "));
