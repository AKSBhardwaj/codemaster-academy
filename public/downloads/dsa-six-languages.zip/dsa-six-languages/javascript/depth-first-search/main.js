const graph = [[1, 2], [0, 3], [0, 3], [1, 2]];
const seen = new Array(graph.length).fill(false);
const order = [];
function visit(current) {
  seen[current] = true;
  order.push(current);
  for (const next of graph[current]) {
    if (!seen[next]) visit(next);
  }
}
visit(0);
console.log(order.join(" "));
