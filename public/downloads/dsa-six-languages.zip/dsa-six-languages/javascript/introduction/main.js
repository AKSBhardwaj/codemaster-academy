const scores = [4, 7, 2];
let total = 0;
for (const score of scores) {
  total += score;
}
console.log(total);
