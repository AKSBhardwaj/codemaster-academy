const a = [1, 2, 4, 6, 8];
const target = 10;
const n = a.length;
let left = 0, right = n - 1;
let found = false;
while (left < right) {
    let sum = a[left] + a[right];
    if (sum == target) {
        found = true;
        break;
    }
    if (sum < target) left++;
    else right--;
}
console.log(found ? `${left} ${right}` : "not found");
