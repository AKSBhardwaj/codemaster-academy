const last = { value: 9, next: null };
const middle = { value: 6, next: last };
const head = { value: 3, next: middle };
let current = head;
while (current !== null) {
  console.log(current.value);
  current = current.next;
}
