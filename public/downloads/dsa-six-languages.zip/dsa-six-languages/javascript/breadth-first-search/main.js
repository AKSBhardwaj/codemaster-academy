const graph = [[1, 2], [0, 3], [0, 3], [1, 2]];
const seen = new Array(graph.length).fill(false);
const queue = [0];
seen[0] = true;
let head = 0;
while (head < queue.length) {
  const current = queue[head++];
  for (const next of graph[current]) {
    if (!seen[next]) {
      seen[next] = true;
      queue.push(next);
    }
  }
}
console.log(queue.join(" "));
