const books = new Map([[2, 3], [5, 1]]);
books.set(2, 6);
if (books.has(2)) console.log(books.get(2));
console.log(books.size);
