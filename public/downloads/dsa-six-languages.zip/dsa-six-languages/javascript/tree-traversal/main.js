const root = {
  value: 4,
  left: {
    value: 2,
    left: { value: 1, left: null, right: null },
    right: { value: 3, left: null, right: null }
  },
  right: { value: 6, left: null, right: null }
};
function inorder(node, order) {
  if (node === null) return;
  inorder(node.left, order);
  order.push(node.value);
  inorder(node.right, order);
}
const order = [];
inorder(root, order);
console.log(order.join(" "));
