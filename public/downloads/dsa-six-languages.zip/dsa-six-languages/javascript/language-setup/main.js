console.log(4 + 7 + 2);
