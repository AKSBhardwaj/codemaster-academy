const edges = [
  [0, 1, 1],
  [1, 0, 0],
  [1, 0, 0]
];
const vertex = 0;
if (vertex >= 0 && vertex < edges.length) {
  for (let neighbour = 0; neighbour < edges.length; neighbour++) {
    if (edges[vertex][neighbour] === 1) console.log(neighbour);
  }
}
