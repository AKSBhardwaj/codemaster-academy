const a = [4, 2, 3, 1];
const n = a.length;
for (let start = 0; start < n - 1; start++) {
    let smallest = start;
    for (let i = start + 1; i < n; i++) {
        if (a[i] < a[smallest]) smallest = i;
    }
    let temp = a[start];
    a[start] = a[smallest];
    a[smallest] = temp;
}
console.log(a.join(" "));
