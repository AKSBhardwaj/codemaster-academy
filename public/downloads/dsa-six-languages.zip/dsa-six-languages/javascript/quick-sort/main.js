function partition(a, low, high) {
    let pivot = a[high];
    let place = low;
    for (let i = low; i < high; i++) {
        if (a[i] <= pivot) {
            let temp = a[i];
            a[i] = a[place];
            a[place] = temp;
            place++;
        }
    }
    let pivotTemp = a[place];
    a[place] = a[high];
    a[high] = pivotTemp;
    return place;
}

function quickSort(a, low, high) {
    if (low >= high) return;
    let pivotPosition = partition(a, low, high);
    quickSort(a, low, pivotPosition - 1);
    quickSort(a, pivotPosition + 1, high);
}
const a = [4, 2, 3, 1];
quickSort(a, 0, a.length - 1);
console.log(a.join(" "));
