const keys = Array(4).fill(0);
const values = Array(4).fill(0);
const used = Array(4).fill(false);
const inputs = [5, 9];
const amounts = [20, 40];
for (let i = 0; i < inputs.length; i++) {
  for (let step = 0; step < 4; step++) {
    const slot = (inputs[i] % 4 + step) % 4;
    if (!used[slot] || keys[slot] === inputs[i]) {
      used[slot] = true;
      keys[slot] = inputs[i];
      values[slot] = amounts[i];
      break;
    }
  }
}
const target = 9;
for (let step = 0; step < 4; step++) {
  const slot = (target % 4 + step) % 4;
  if (!used[slot]) break;
  if (keys[slot] === target) {
    console.log(values[slot]);
    break;
  }
}
