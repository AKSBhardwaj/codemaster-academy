function findFirst(a, target) {
  for (let i = 0; i < a.length; i++) {
    if (a[i] === target) return i;
  }
  return -1;
}
const a = [9, 4, 7, 4];
console.log(findFirst(a, 7));
console.log(findFirst(a, 6));
