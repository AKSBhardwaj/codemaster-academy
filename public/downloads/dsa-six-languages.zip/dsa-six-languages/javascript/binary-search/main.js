function binarySearch(a, target) {
  let low = 0;
  let high = a.length - 1;
  while (low <= high) {
    const mid = low + Math.floor((high - low) / 2);
    if (a[mid] === target) return mid;
    if (a[mid] < target) low = mid + 1;
    else high = mid - 1;
  }
  return -1;
}
const a = [2, 4, 6, 8, 10];
console.log(binarySearch(a, 8));
console.log(binarySearch(a, 7));
