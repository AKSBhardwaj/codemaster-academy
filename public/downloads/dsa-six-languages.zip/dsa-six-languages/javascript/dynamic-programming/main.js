const n = 4;
const ways = new Array(n + 1).fill(0);
ways[0] = 1;
for (let step = 1; step <= n; step++) {
    ways[step] = ways[step - 1];
    if (step >= 2) ways[step] += ways[step - 2];
}
console.log(ways[n]);
