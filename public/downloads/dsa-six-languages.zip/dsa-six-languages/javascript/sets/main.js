const cards = new Set([4, 4, 7]);
console.log(cards.size);
console.log(cards.has(7) ? 1 : 0);
