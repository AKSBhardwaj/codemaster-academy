const root = {
  value: 8,
  left: { value: 3, left: null, right: null },
  right: { value: 10, left: null, right: null }
};
function sum(node) {
  if (node === null) return 0;
  return node.value + sum(node.left) + sum(node.right);
}
console.log(sum(root));
