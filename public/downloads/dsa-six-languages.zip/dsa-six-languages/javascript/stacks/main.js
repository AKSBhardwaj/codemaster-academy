const stack = [];
stack.push(10);
stack.push(20);
if (stack.length > 0) console.log(stack.pop());
if (stack.length > 0) console.log(stack[stack.length - 1]);
