const heap = [2, 4, 7, 9];
let size = heap.length;
if (size > 0) {
  const removed = heap[0];
  heap[0] = heap[size - 1];
  size--;
  let parent = 0;
  while (2 * parent + 1 < size) {
    let child = 2 * parent + 1;
    const right = child + 1;
    if (right < size && heap[right] < heap[child]) child = right;
    if (heap[parent] <= heap[child]) break;
    const temp = heap[parent];
    heap[parent] = heap[child];
    heap[child] = temp;
    parent = child;
  }
  console.log(removed);
  if (size > 0) console.log(heap[0]);
}
