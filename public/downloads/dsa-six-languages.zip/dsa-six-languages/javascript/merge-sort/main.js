function mergeSort(a, buffer, left, right) {
  if (left >= right) return;
  let mid = left + Math.floor((right - left) / 2);
  mergeSort(a, buffer, left, mid);
  mergeSort(a, buffer, mid + 1, right);
  let i = left, j = mid + 1, k = left;
  while (i <= mid && j <= right) {
      if (a[i] <= a[j]) buffer[k++] = a[i++];
      else buffer[k++] = a[j++];
  }
  while (i <= mid) buffer[k++] = a[i++];
  while (j <= right) buffer[k++] = a[j++];
  for (let pos = left; pos <= right; pos++) a[pos] = buffer[pos];
}
const a = [4, 2, 3, 1];
const buffer = new Array(a.length);
mergeSort(a, buffer, 0, a.length - 1);
console.log(a.join(" "));
