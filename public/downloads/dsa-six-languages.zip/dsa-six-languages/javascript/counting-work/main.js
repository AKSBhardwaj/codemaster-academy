const scores = [3, 6, 9];
const target = 9;
let checks = 0;
for (const score of scores) {
  checks++;
  if (score === target) break;
}
console.log(checks);
