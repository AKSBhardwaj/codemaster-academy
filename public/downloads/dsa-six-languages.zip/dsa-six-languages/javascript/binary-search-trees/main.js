const root = {
  value: 8,
  left: { value: 3, left: null, right: null },
  right: { value: 10, left: null, right: null }
};
let current = root;
const target = 10;
let found = -1;
while (current !== null) {
  if (target === current.value) {
    found = current.value;
    break;
  }
  current = target < current.value ? current.left : current.right;
}
console.log(found);
