const queue = [];
let head = 0;
queue.push(10);
queue.push(20);
if (head < queue.length) console.log(queue[head++]);
if (head < queue.length) console.log(queue[head]);
